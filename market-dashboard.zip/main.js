fetch('marketdata.js')
  .then(res => res.text())
  .then(script => {
    const handler = new Function('req', 'res', script + '; return handler(req, res);');
    const fakeRes = {
      status: code => ({
        json: data => {
          const container = document.getElementById('market-data');
          container.innerHTML = data.map(item => `
            <div class="card">
              <h2>${item.symbol}</h2>
              <p>LTP: ₹${item.ltp}</p>
              <p>Change: ${item.change}%</p>
              <p>Time: ${item.time}</p>
            </div>
          `).join('');
        }
      })
    };
    handler({}, fakeRes);
  });
